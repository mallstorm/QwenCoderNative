# Qwen Coder Native
Android WebView wrapper for https://coder.qwen.ai. Open in Android Studio (JDK 17), sync Gradle, Build > Build APK(s).

## Important
OAuth redirects through an external browser are not guaranteed to return to the embedded WebView session. Login flows need validation on device. The website's responsive layout is controlled by Qwen; the app does not inject CSS or alter site content. Requires network and Android System WebView. No credentials are intercepted or stored by app code.


## Голосовая диктовка
Нативная кнопка микрофона справа снизу запускает Android SpeechRecognizer (ru-RU). После распознавания текст вставляется в поле ввода сайта без отправки. Нужны разрешение RECORD_AUDIO и установленная служба распознавания речи. Положение кнопки и DOM-вставку необходимо проверить на актуальной версии coder.qwen.ai: сайт может менять разметку.
