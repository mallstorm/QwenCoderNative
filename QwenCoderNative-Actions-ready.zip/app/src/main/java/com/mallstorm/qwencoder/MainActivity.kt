package com.mallstorm.qwencoder

import android.app.Activity
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.ImageButton
import android.view.Gravity
import android.graphics.drawable.GradientDrawable
import android.Manifest
import android.content.pm.PackageManager
import android.speech.RecognitionListener
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.webkit.*
import android.view.View
import android.widget.FrameLayout
import android.widget.ProgressBar
import android.widget.Toast
import android.view.WindowManager
import android.webkit.WebChromeClient.FileChooserParams

class MainActivity : Activity() {
 private lateinit var web: WebView
 private lateinit var progress: ProgressBar
 private var fileCallback: ValueCallback<Array<Uri>>? = null
 private val fileRequest = 1001
 private var recognizer: SpeechRecognizer? = null
 private lateinit var mic: ImageButton
 private var listening = false
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  window.statusBarColor = Color.rgb(24,24,24)
  window.navigationBarColor = Color.rgb(24,24,24)
  window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
  val root = FrameLayout(this).apply { setBackgroundColor(Color.rgb(30,30,30)) }
  web = WebView(this)
  root.addView(web, FrameLayout.LayoutParams(-1,-1))
  progress = ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal).apply { max=100; visibility=View.GONE }
  root.addView(progress,FrameLayout.LayoutParams(-1,6))
  mic = ImageButton(this).apply {
   setImageResource(android.R.drawable.ic_btn_speak_now)
   setColorFilter(Color.WHITE)
   background = GradientDrawable().apply { setColor(Color.rgb(62,72,103)); cornerRadius = 32f * resources.displayMetrics.density }
   contentDescription = "Голосовой ввод"
   setOnClickListener { if(listening) stopDictation() else startDictation() }
  }
  val density=resources.displayMetrics.density
  val micParams=FrameLayout.LayoutParams((42*density).toInt(),(42*density).toInt(),Gravity.BOTTOM or Gravity.RIGHT).apply {
   rightMargin=(65*density).toInt();bottomMargin=(25*density).toInt()
  }
  root.addView(mic,micParams)
  setContentView(root)
  CookieManager.getInstance().setAcceptCookie(true)
  CookieManager.getInstance().setAcceptThirdPartyCookies(web,true)
  web.settings.apply {
   javaScriptEnabled=true; domStorageEnabled=true; databaseEnabled=true
   allowFileAccess=false; allowContentAccess=true
   setSupportMultipleWindows(false)
   javaScriptCanOpenWindowsAutomatically=false
   builtInZoomControls=false; displayZoomControls=false
   useWideViewPort=true; loadWithOverviewMode=true
   mixedContentMode=WebSettings.MIXED_CONTENT_NEVER_ALLOW
   userAgentString = userAgentString.replace("; wv", "")
  }
  WebView.setWebContentsDebuggingEnabled(false)
  web.webViewClient=object:WebViewClient(){
   override fun shouldOverrideUrlLoading(view:WebView?, request:WebResourceRequest?):Boolean {
    val uri=request?.url ?: return false
    val scheme=uri.scheme ?: return true
    if (scheme!="https") { if(scheme=="mailto"||scheme=="tel") openExternal(uri); return true }
    val host=uri.host.orEmpty().lowercase()
    // OAuth login pages must run in a browser, not embedded WebView.
    if (host=="accounts.google.com" || host=="github.com" && uri.path.orEmpty().startsWith("/login") || host=="github.com" && uri.path.orEmpty().startsWith("/oauth")) { openExternal(uri); return true }
    return false
   }
   override fun onReceivedError(view:WebView?,request:WebResourceRequest?,error:WebResourceError?) {
    if(request?.isForMainFrame==true) Toast.makeText(this@MainActivity,"Ошибка подключения. Проверьте интернет или VPN.",Toast.LENGTH_LONG).show()
   }
  }
  web.webChromeClient=object:WebChromeClient(){
   override fun onProgressChanged(view:WebView?,newProgress:Int){progress.progress=newProgress;progress.visibility=if(newProgress>=100)View.GONE else View.VISIBLE}
   override fun onShowFileChooser(view:WebView?,callback:ValueCallback<Array<Uri>>?,params:FileChooserParams?):Boolean {
    fileCallback?.onReceiveValue(null); fileCallback=callback
    return try { startActivityForResult(params?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply { type="*/*"; addCategory(Intent.CATEGORY_OPENABLE) },fileRequest); true } catch(e:Exception){fileCallback=null;false}
   }
  }
  if(savedInstanceState==null) web.loadUrl("https://coder.qwen.ai/") else web.restoreState(savedInstanceState)
 }
 private fun startDictation(){
  if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){
   requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO),2001);return
  }
  if(!SpeechRecognizer.isRecognitionAvailable(this)){
   Toast.makeText(this,"Служба распознавания речи недоступна",Toast.LENGTH_LONG).show();return
  }
  recognizer?.destroy()
  recognizer=SpeechRecognizer.createSpeechRecognizer(this).also { sr ->
   sr.setRecognitionListener(object:RecognitionListener {
    override fun onReadyForSpeech(params:Bundle?){ }
    override fun onBeginningOfSpeech(){ }
    override fun onRmsChanged(rmsdB:Float){ }
    override fun onBufferReceived(buffer:ByteArray?){ }
    override fun onEndOfSpeech(){ }
    override fun onError(error:Int){ finishDictation();Toast.makeText(this@MainActivity,"Не удалось распознать речь ($error)",Toast.LENGTH_SHORT).show() }
    override fun onResults(results:Bundle?){
     val words=results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
     if(!words.isNullOrBlank()) insertRecognizedText(words)
     finishDictation()
    }
    override fun onPartialResults(partialResults:Bundle?){ }
    override fun onEvent(eventType:Int,params:Bundle?){ }
   })
  }
  listening=true
  mic.setColorFilter(Color.RED)
  recognizer?.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
   putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
   putExtra(RecognizerIntent.EXTRA_LANGUAGE,"ru-RU")
   putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,false)
  })
 }
 private fun stopDictation(){ recognizer?.stopListening() }
 private fun finishDictation(){ listening=false;mic.setColorFilter(Color.WHITE);recognizer?.destroy();recognizer=null }
 private fun insertRecognizedText(words:String){
  val encoded=android.util.Base64.encodeToString(words.toByteArray(Charsets.UTF_8),android.util.Base64.NO_WRAP)
  web.evaluateJavascript("""(function(){
   const text=decodeURIComponent(escape(atob('$encoded')));
   const active=document.activeElement;
   const items=[...document.querySelectorAll('textarea,[contenteditable="true"],[role="textbox"],input[type="text"]')];
   const el=(active&&items.includes(active))?active:items.filter(e=>e.getClientRects().length).pop();
   if(!el)return false;
   el.focus();
   if(el.isContentEditable){
    const sel=window.getSelection();const range=document.createRange();range.selectNodeContents(el);range.collapse(false);sel.removeAllRanges();sel.addRange(range);
    document.execCommand('insertText',false,(el.textContent?.trim()?' ':'')+text);
    el.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:text}));
   } else {
    const proto=el.tagName==='TEXTAREA'?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;
    const setter=Object.getOwnPropertyDescriptor(proto,'value').set;
    setter.call(el,el.value+(el.value?' ':'')+text);
    el.dispatchEvent(new Event('input',{bubbles:true}));
    el.dispatchEvent(new Event('change',{bubbles:true}));
   }
   return true;
  })();""".trimIndent()) { result -> if(result!="true")Toast.makeText(this,"Не найдено поле ввода Qwen",Toast.LENGTH_SHORT).show() }
 }
 override fun onRequestPermissionsResult(requestCode:Int,permissions:Array<out String>,grantResults:IntArray){
  super.onRequestPermissionsResult(requestCode,permissions,grantResults)
  if(requestCode==2001&&grantResults.firstOrNull()==PackageManager.PERMISSION_GRANTED)startDictation()
 }
 private fun openExternal(uri:Uri){ try { startActivity(Intent(Intent.ACTION_VIEW,uri).addCategory(Intent.CATEGORY_BROWSABLE)) } catch (_:Exception) { Toast.makeText(this,"Не удалось открыть ссылку",Toast.LENGTH_SHORT).show() } }
 override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){super.onActivityResult(requestCode,resultCode,data);if(requestCode==fileRequest){fileCallback?.onReceiveValue(if(resultCode==RESULT_OK) WebChromeClient.FileChooserParams.parseResult(resultCode,data) else null);fileCallback=null}}
 override fun onSaveInstanceState(outState:Bundle){web.saveState(outState);super.onSaveInstanceState(outState)}
 @Deprecated("Legacy back handling") override fun onBackPressed(){if(web.canGoBack())web.goBack() else super.onBackPressed()}
 override fun onDestroy(){recognizer?.destroy();web.destroy();super.onDestroy()}
}
